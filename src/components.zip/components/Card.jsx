import React, { useState, useRef, useEffect } from 'react';

const Card = (props) => {
  const Ref = useRef(null);
  const [st, setStatus] = useState(props.status);
  const [timer, setTimer] = useState("00:00:00");

  const getTimeRemaining = (e) => {
    const total = Date.parse(e) - Date.parse(new Date());
    const seconds = Math.floor((total / 1000) % 60);
    const minutes = Math.floor((total / 1000 / 60) % 60);
    const hours = Math.floor((total / 1000 / 60 / 60) % 24);
    return {
      total,
      hours,
      minutes,
      seconds
    };
  };

  const startTimer = (e) => {
    let { total, hours, minutes, seconds } = getTimeRemaining(e);
    if (total >= 0) {
      setTimer(
        (hours > 9 ? hours : '0' + hours) + ':' +
        (minutes > 9 ? minutes : '0' + minutes) + ':' +
        (seconds > 9 ? seconds : '0' + seconds)
      );
      setStatus("Ongoing");
    } else {
      setStatus("Complete");
    }
  };

  const clearTimer = (e) => {
    if (Ref.current) clearInterval(Ref.current);
    const id = setInterval(() => {
      startTimer(e);
    }, 1000);
    Ref.current = id;
  };

  const getDeadTime = () => {
    let tim = new Date(props.time);
    return tim;
  };

  useEffect(() => {
    clearTimer(getDeadTime());
  }, []);

  return (
    <div className="__card">
      <img src={props.img} alt="img" />
      <span className="cont--header">{props.title}</span>
      <span className="cont">Price: $ {props.price} </span>
      <span className="cont">Time Remaining: {timer} </span>
      <span className="cont">Status: {st}</span>
    </div>
  );
};

export default Card;
