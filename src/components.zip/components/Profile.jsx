import React, { useState } from "react";
import "./Profile.css";
import Header from './Header'
import Footer from './Footer'

function Profile() {
  const [fullName, setFullName] = useState("");
  const [gender, setGender] = useState("");
  const [email, setEmail] = useState("");
  const [mobile, setMobile] = useState("");
  const [address, setAddress] = useState("");

  const handleSubmit = (e) => {
    e.preventDefault();
    // Perform any necessary actions with the submitted data
    console.log("Submitted data:", { fullName, gender, email, mobile, address });
    // Reset form fields
    setFullName("");
    setGender("");
    setEmail("");
    setMobile("");
    setAddress("");
  };

  return (
    <div>
      <Header />
      <div className="profile-container">
      <h2>Profile Page</h2>
      <form className="profile-form" onSubmit={handleSubmit}>
        <table className="profile-table">
          <tbody>
            <tr>
              <td>Full Name:</td>
              <td>
                <input
                  type="text"
                  value={fullName}
                  onChange={(e) => setFullName(e.target.value)}
                  required
                />
              </td>
            </tr>
            <tr>
              <td>Gender:</td>
              <td>
                <label>
                  <input
                    type="radio"
                    value="Male"
                    checked={gender === "Male"}
                    onChange={(e) => setGender(e.target.value)}
                    required
                  />
                  Male
                </label>
                <label>
                  <input
                    type="radio"
                    value="Female"
                    checked={gender === "Female"}
                    onChange={(e) => setGender(e.target.value)}
                    required
                  />
                  Female
                </label>
              </td>
            </tr>
            <tr>
              <td>Email:</td>
              <td>
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  required
                />
              </td>
            </tr>
            <tr>
              <td>Mobile:</td>
              <td>
                <input
                  type="tel"
                  value={mobile}
                  onChange={(e) => setMobile(e.target.value)}
                  required
                />
              </td>
            </tr>
            <tr>
              <td>Address:</td>
              <td>
                <textarea
                  value={address}
                  onChange={(e) => setAddress(e.target.value)}
                  required
                />
              </td>
            </tr>
          </tbody>
        </table>
        <button type="submit">Submit</button>
      </form>
      </div>
      <Footer />
    </div>
    
  );
}

export default Profile;
