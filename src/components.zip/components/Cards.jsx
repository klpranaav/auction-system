import React from 'react';
import Card from './Card';
import CardData from './CardData';
import './Cards.css';
import Footer from './Footer';
import Header from './Header';

const Cards = () => {
  const cardElements = CardData.map((data) => (
    <Card
      key={data.id}
      img={data.img}
      title={data.title}
      price={data.price}
      time={data.time}
      status={data.status}
    />
  ));

  return (
    <div>
      <Header />
      <div className="cards">{cardElements}</div>
      <Footer className="footer" />
    </div>
  );
};

export default Cards;
