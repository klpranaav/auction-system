import React, { useState } from 'react';
import axios from "axios";
import 'bootstrap/dist/css/bootstrap.min.css';
import Footer from './Footer';
import './AddProducts.css';
import { Container, Form, Row, Col, Button } from 'react-bootstrap';
import Header from './Header.jsx';

const AddProducts = () => {
  const [name, setName] = useState('');
  const [price, setPrice] = useState('');
  const [email, setEmail] = useState('');
  const [condition, setCondition] = useState('');
  const [desc, setDesc] = useState('');
  const [img, setImg] = useState('');

  async function submit(e) {
    e.preventDefault();
    try {
      await axios.post("http://localhost:8080/addproduct", { name, price, email, condition, desc, img })
        .then(res => {
          alert("Product Added");
        })
        .catch(e => {
          alert("Error");
          console.log(e);
        });
    } catch (e) {
      console.log(e);
    }
  }

  return (
    <>
      <Header />
      <div className='container add-products'>
        <Container className='add-products'>
          <div className='form'>
            <h1>Enter Product Details</h1>
            <Form action='POST'>
              <Row className='mb-1'>
                <Form.Label column xs={12} sm={2}>
                  Product Name:
                </Form.Label>
                <Col xs={12} sm={10}>
                  <Form.Control type='text' id='name' placeholder='Product Name' onChange={(e) => setName(e.target.value)} required className='inp' />
                </Col>
              </Row>
              <Row className='mb-4'>
                <Form.Label column xs={12} sm={2}>
                  Price:
                </Form.Label>
                <Col xs={12} sm={10}>
                  <Form.Control type='number' id='price' placeholder='Price' onChange={(e) => setPrice(e.target.value)} required className='inp' />
                </Col>
              </Row>
              <Row className='mb-4'>
                <Form.Label column xs={12} sm={2}>
                  Email ID:
                </Form.Label>
                <Col xs={12} sm={10}>
                  <Form.Control type='email' id='email' placeholder='Email ID' onChange={(e) => setEmail(e.target.value)} required className='inp' />
                </Col>
              </Row>
              <Row className='mb-1'>
                <Form.Label column xs={12} sm={2}>
                  Product Condition:
                </Form.Label>
                <Col xs={12} sm={10}>
                  <Form.Control as='select' id='condition' onChange={(e) => setCondition(e.target.value)} required className='inp'>
                    <option value='' disabled selected>
                      Select Item Condition
                    </option>
                    <option value='used'>Used</option>
                    <option value='new'>New</option>
                  </Form.Control>
                </Col>
              </Row>
              <Row className='mb-4'>
                <Form.Label column xs={12} sm={2}>
                  Product Description:
                </Form.Label>
                <Col xs={12} sm={10}>
                  <Form.Control as='textarea' placeholder='Description' id='desc' onChange={(e) => setDesc(e.target.value)} required className='inp' />
                </Col>
              </Row>
              <Row className='mb-4'>
                <Form.Label column xs={12} sm={2}>
                  Product Images
                </Form.Label>
                <Col xs={12} sm={10}>
                  <Form.Control type='file' id='img' accept='.png, .jpg, .jpeg' onChange={(e) => setImg(e.target.files[0])} required multiple className='inp' />
                </Col>
              </Row>
              <Row className='mb-4'>
                <Col xs={12} sm={{ span: 10, offset: 2 }}>
                  <Button type='submit' variant='outline-danger' onClick={submit} className='d-block mx-auto'>
                    Submit
                  </Button>
                </Col>
              </Row>
            </Form>
          </div>
        </Container>
      </div>
      <Footer />
    </>
  );
}

export default AddProducts;
